import { jsonResponse, parseJsonBody, queryDB, queryOne } from '../../../_utils';

export async function onRequestPut(context) {
  const { env, params, request } = context;
  const { id } = params;
  const body = await parseJsonBody(request);
  const userId = request.headers.get('X-User-Id') || body.user_id;

  if (!userId) {
    return jsonResponse({ success: false, message: '缺少用户 ID' }, 400);
  }

  const save = await queryOne(env, 'SELECT * FROM saves WHERE id = ?', [id]);
  if (!save) {
    return jsonResponse({ success: false, message: '存档不存在' }, 404);
  }

  if (save.user_id !== userId) {
    return jsonResponse({ success: false, message: '无权移动此存档' }, 403);
  }

  const groupId = body.group_id || null;
  await queryDB(env, 'UPDATE saves SET group_id = ? WHERE id = ?', [groupId, id]);

  return jsonResponse({
    success: true,
    message: '存档移动成功',
  });
}