import { jsonResponse, queryAll } from '../../../_utils';

export async function onRequestGet(context) {
  const { env, params } = context;
  const { id } = params;

  const saves = await queryAll(env, 'SELECT id, name, file_name, file_size, group_id, created_at FROM saves WHERE user_id = ? ORDER BY created_at DESC', [id]);
  
  return jsonResponse({
    success: true,
    data: saves,
  });
}