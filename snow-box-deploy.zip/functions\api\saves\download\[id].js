import { jsonResponse, queryOne, readFileFromChunks } from '../../../_utils';

export async function onRequestGet(context) {
  const { env, params } = context;
  const { id } = params;

  const save = await queryOne(env, 'SELECT * FROM saves WHERE id = ?', [id]);
  if (!save) {
    return jsonResponse({ success: false, message: '存档不存在' }, 404);
  }

  const fileData = await readFileFromChunks(env, id, 'save_file');
  if (!fileData) {
    return jsonResponse({ success: false, message: '存档文件不存在' }, 404);
  }

  return new Response(fileData, {
    headers: {
      'Content-Type': 'application/octet-stream',
      'Content-Disposition': `attachment; filename="${save.file_name}"`,
      'Access-Control-Allow-Origin': '*',
    },
  });
}