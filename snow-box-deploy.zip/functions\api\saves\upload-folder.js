import { jsonResponse, parseFormData, queryDB, generateId, getCurrentTime, writeFileInChunks } from '../../_utils';

export async function onRequestPost(context) {
  const { env, request } = context;
  const userId = request.headers.get('X-User-Id');
  
  if (!userId) {
    return jsonResponse({ success: false, message: '缺少用户 ID' }, 400);
  }

  const formData = await parseFormData(request);
  if (!formData) {
    return jsonResponse({ success: false, message: '请求格式错误' }, 400);
  }

  const gameName = formData.get('game_name');
  const files = formData.getAll('files[]');
  
  if (!gameName || !files || files.length === 0) {
    return jsonResponse({ success: false, message: '游戏名称和文件必填' }, 400);
  }

  const uploadedFiles = [];
  for (const file of files) {
    const saveId = generateId();
    const createdAt = getCurrentTime();
    const fileBytes = await file.arrayBuffer();
    const fileName = file.name;
    const fileSize = fileBytes.byteLength;

    await queryDB(env,
      'INSERT INTO saves (id, user_id, name, file_name, file_size, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      [saveId, userId, gameName, fileName, fileSize, createdAt]
    );

    await writeFileInChunks(env, saveId, 'save_file', fileBytes);

    uploadedFiles.push({
      id: saveId,
      file_name: fileName,
      file_size: fileSize,
    });
  }

  return jsonResponse({
    success: true,
    message: `文件夹上传成功，共 ${uploadedFiles.length} 个文件`,
    data: uploadedFiles,
  });
}