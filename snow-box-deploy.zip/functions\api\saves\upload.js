import { jsonResponse, parseFormData, queryDB, generateId, getCurrentTime, writeFileInChunks } from '../../_utils';

export async function onRequestPost(context) {
  const { env, request } = context;
  
  const formData = await parseFormData(request);
  if (!formData) {
    return jsonResponse({ success: false, message: '请求格式错误' }, 400);
  }

  const userId = request.headers.get('X-User-Id') || formData.get('user_id');
  if (!userId) {
    return jsonResponse({ success: false, message: '缺少用户 ID' }, 400);
  }

  const gameName = formData.get('game_name') || formData.get('name');
  const file = formData.get('file');
  const groupId = formData.get('group_id');
  
  if (!gameName || !file) {
    return jsonResponse({ success: false, message: '游戏名称和文件必填' }, 400);
  }

  const saveId = generateId();
  const createdAt = getCurrentTime();
  const fileBytes = await file.arrayBuffer();
  const fileName = file.name;
  const fileSize = fileBytes.byteLength;

  await queryDB(env,
    'INSERT INTO saves (id, user_id, name, file_name, file_size, group_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [saveId, userId, gameName, fileName, fileSize, groupId || null, createdAt]
  );

  await writeFileInChunks(env, saveId, 'save_file', fileBytes);

  return jsonResponse({
    success: true,
    message: '存档上传成功',
    data: {
      id: saveId,
      game_name: gameName,
      file_name: fileName,
      file_size: fileSize,
      group_id: groupId || null,
      created_at: createdAt,
    },
  });
}