import { jsonResponse, parseFormData, queryDB, queryOne, writeFileInChunks, getCurrentTime } from '../../../_utils';

export async function onRequestPut(context) {
  const { env, params, request } = context;
  const { id } = params;
  
  const formData = await parseFormData(request);
  if (!formData) {
    return jsonResponse({ success: false, message: '请求格式错误' }, 400);
  }

  const userId = request.headers.get('X-User-Id') || formData.get('user_id');
  if (!userId) {
    return jsonResponse({ success: false, message: '缺少用户 ID' }, 400);
  }

  const save = await queryOne(env, 'SELECT * FROM saves WHERE id = ?', [id]);
  if (!save) {
    return jsonResponse({ success: false, message: '存档不存在' }, 404);
  }

  if (save.user_id !== userId) {
    return jsonResponse({ success: false, message: '无权替换此存档' }, 403);
  }

  const file = formData.get('file');
  if (!file) {
    return jsonResponse({ success: false, message: '文件必填' }, 400);
  }

  const fileBytes = await file.arrayBuffer();
  const fileName = file.name;
  const fileSize = fileBytes.byteLength;

  await queryDB(env, 'DELETE FROM file_chunks WHERE file_id = ? AND file_type = ?', [id, 'save_file']);
  await writeFileInChunks(env, id, 'save_file', fileBytes);

  await queryDB(env, 'UPDATE saves SET file_name = ?, file_size = ?, updated_at = ? WHERE id = ?',
    [fileName, fileSize, getCurrentTime(), id]
  );

  return jsonResponse({
    success: true,
    message: '存档替换成功',
    data: {
      id: id,
      file_name: fileName,
      file_size: fileSize,
    },
  });
}