import { jsonResponse, queryAll } from '../../../../_utils';

export async function onRequestGet(context) {
  const { env, params } = context;
  const { id } = params;

  const groups = await queryAll(env, 'SELECT id, name, created_at FROM save_groups WHERE user_id = ? ORDER BY created_at DESC', [id]);
  
  return jsonResponse({
    success: true,
    data: groups,
  });
}